#=======================================================================
# 
# Bellhop: Calibration case
# Faro, Qua 19 Abr 2023 21:08:23 WEST 
# Written by Tordar 
# 
#=======================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from plotray import *

print("Bellhop - Calibration case:") 
print("Ray trace run")
print("Geometric hat beams in Cartesian coordinates")

system("bellhop.exe calibray")

figure(1)
plotray('calibray.ray')
xlabel('Range (m)')
ylabel('Depth (m)')
title("Bellhop - Calibration case")

show()

print("done.")
