#=======================================================================
# 
# Bellhop: Pekeris case
# Faro, Qua 19 Abr 2023 21:09:19 WEST 
# Written by Tordar 
# 
#=======================================================================

from os import *
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from wbellhopenvfil import *
from readshd import *

print('Pekeris waveguide:') 

case_title = 'Pekeris waveguide, RD bottom'

freq   = 50.0
Rmaxkm =   5.0; Rmax = Rmaxkm*1000.0 
Dmax   = 100.0 
cw   = 1500.0 # sound speed in water
cb   = 1700.0 # sound speed in lower halfspace
rhow =  1.0   # density in water
rhob =  2.0   # density in lower halfspace

source_nrays =  1789   # number of propagation rays considered #
source_aperture = 89.0 # maximum launching angle (degrees) #
source_ray_step =  0.0 # ray calculation step (meters) #

#==================================================================
#  
#  Source properties 
#  
#==================================================================

zs   = array([50.0])
rs   = array([ 0.0])
zbox = 101.0 
rbox = 5.1  # km!!!!!
box  = array([source_ray_step,zbox,rbox])
thetas = array([source_nrays,-source_aperture,source_aperture])
p      = [] 
comp   = '' 
position = 50 

source_data = {"zs":zs, "box":box, "f":freq, "thetas":thetas, "p":p, "comp":comp}

#==================================================================
#  
#  Surface definition:
#  
#==================================================================

itype = [] 
xati  = []  # The *.ati file won't be written  
p     = []  # Surface properties
aunits= []

surface_data = {"itype":itype,"x":xati,"p":p,"units":aunits}

#==================================================================
#  
#  Sound speed:
#  
#==================================================================

z = array([0.0,Dmax])
c = array([cw,cw])
r = []

ssp_data = {"r":r,"z":z,"c":c}

#==================================================================
#  
#  Bottom:
#  
#==================================================================
rbtykm = array([0.0, 2.5, 5.0]); rbty = rbtykm*1000
zbty   = array([Dmax,Dmax,Dmax])
cp     = array([1700.0,1550.0,1550.0])
rho    = array([1.2,1.2,1.2])
aR     = array([0.5,0.5,0.5])
aI     = array([0.0,0.0,0.0]); bI = aI
itype  = '''LL''' # Long format
bunits = '''W'''
xbty   = array([rbtykm,zbty,cp,aR,rho,aI,bI]) # Bottom data 
p      = array([1590.0,0.0,1.2,0.5,0.0])

bottom_data = {"itype":itype,"x":xbty,"p":p,"units":bunits}

#==================================================================
#  
#  Array: 
#  
#==================================================================

options1    = '''CVW''' # No ati file expected  
options2    = '''A~'''
options3    = '''C''' # Coherent TL (rewrite final block accordingly) 
options4    = [];
rarray = linspace(0,Rmaxkm,501); 
zarray = linspace(0,Dmax  ,101);

options = {"options1":options1,"options2":options2,"options3":options3,"options4":options4,"rarray":rarray,"zarray":zarray}

print("Writing environmental file...")

wbellhopenvfil('pekeris',case_title,source_data,surface_data,ssp_data,bottom_data,options)

print( "Running Bellhop..." )
system("bellhop.exe pekeris")

print( "Reading output data..." )
filename = 'pekeris.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

p = squeeze( pressure, axis=(0,1) )
tl = 20*log10( abs( p ) )

figure(1)
imshow(tl,extent=[0,Rmax,-Dmax,0], aspect='auto')
colorbar()
plot(rs[0],-zs[0],marker="<",markersize=16,color="k")
xlabel('Range (m)')
ylabel('Depth (m)')
show()

print("done.")
