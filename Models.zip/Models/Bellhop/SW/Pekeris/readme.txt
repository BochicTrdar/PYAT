=======================================================================
Rio de Janeiro, Qua 26 Out 2016 17:01:44 WEST

Bellhop in this case considers that bottom properties change over range... 
Even so shear can not be accounted for.
=======================================================================
