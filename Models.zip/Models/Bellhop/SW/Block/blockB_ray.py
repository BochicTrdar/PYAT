#=======================================================================
# 
# Bellhop: Block ray case
# Faro, Qua 19 Abr 2023 21:06:09 WEST 
# Written by Tordar 
# 
#=======================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("/home/orodrig/FORdoc/Traceo/Python/")
from plotray import *

print("Bellhop - block case")

fid   = open('blockB_ray.bty','r')
itype = fid.readline()
n     = int( fid.readline() )
rbtykm = zeros(n)
zbty   = zeros(n)
for i in range(n):
    theline = str(fid.readline())
    datai = theline.split()
    rbtykm[i] = float( datai[0] )
    zbty[  i] = float( datai[1] )
fid.close()

rbty = rbtykm*1000

system('bellhop.exe blockB_ray')

figure(1)
plotray('blockB_ray.ray')
plot(rbty,-zbty,'k',linewidth=2)
show()

print("done.")
