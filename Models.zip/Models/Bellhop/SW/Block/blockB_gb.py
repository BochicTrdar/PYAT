#==================================================================
#  
#  Bellhop: Block case, Gaussian beams
#  Faro, Qua 19 Abr 2023 21:05:33 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from readshd import *

rs = 0.0

print("Bellhop - Block case, Gaussian beams:")
print("Coherent TL calculation")
print("Geometric gaussian beams")

fid = open('blockB_gb.bty','r')
theline = fid.readline()
theline = fid.readline()
n       = int( theline )
rbtykm  = zeros( n ) 
zbty    = zeros( n )
for i in range(n):
    theline = str( fid.readline() )
    datai = theline.split()
    rbtykm[ i] = float( datai[0] )
    zbty[   i] = float( datai[1] )
fid.close()

rbty = rbtykm*1000

system("bellhop.exe blockB_gb")

filename = 'blockB_gb.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

p = squeeze( pressure, axis=(0,1) )
tl = -20*log10( abs( p ) )
tl[ tl > 160.0 ] = 160.0

figure(1)
imshow(tl,extent=[-rmaxkm,rmaxkm,0,Dmax],aspect='auto',cmap='jet_r',origin='lower')
plot(rbtykm,zbty,'k')
cb = colorbar()
cb.ax.invert_yaxis()
plot(rs,zs,marker="<",markersize=16,color="k")
xlabel('Range (km)')
ylabel('Depth (m)')
title('Bellhop - Block case, Gaussian beams')
xlim(0,rmaxkm)
ylim(Dmax,0)

show()

print("done.")
