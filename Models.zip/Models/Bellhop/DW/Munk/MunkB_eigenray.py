#=======================================================================
# 
# Bellhop: Munk profile
# Faro, Qua 19 Abr 2023 20:32:02 WEST 
# Written by Tordar 
# 
#=======================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from plotray import *

print("Bellhop - Munk profile:") 
print("Eigenray trace run")
print("Geometric hat beams in Cartesian coordinates")

system("bellhop.exe MunkB_eigenray")

figure(1)
plotray('MunkB_eigenray.ray')
xlabel('Range (m)')
ylabel('Depth (m)')
title("Bellhop - Munk profile")

show()

print("done.")

