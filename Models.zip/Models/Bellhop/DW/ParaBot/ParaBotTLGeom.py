#==================================================================
#  
#  Bellhop: Parabolic bottom profile, Geometric beams
#  Faro, Qua 19 Abr 2023 20:39:23 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from readshd import *

rs = 0.0

print("Bellhop - Parabolic bottom profile, Geometric beams:")
print("Coherent TL calculation")
print("Geometric hat beams in Cartesian coordinates")

fid = open('ParaBotTLGeom.ati','r')
theline = fid.readline()
theline = fid.readline()
n       = int( theline )
ratikm  = zeros( n ) 
zati    = zeros( n )
for i in range(n):
    theline = str( fid.readline() )
    datai = theline.split()
    ratikm[ i] = float( datai[0] )
    zati[   i] = float( datai[1] )
fid.close()

rati = ratikm*1000

fid = open('ParaBotTLGeom.bty','r')
theline = fid.readline()
theline = fid.readline()
n       = int( theline )
rbtykm  = zeros( n ) 
zbty    = zeros( n )
for i in range(n):
    theline = str( fid.readline() )
    datai = theline.split()
    rbtykm[ i] = float( datai[0] )
    zbty[   i] = float( datai[1] )
fid.close()

rbty = rbtykm*1000

system("bellhop.exe ParaBotTLGeom")

filename = 'ParaBotTLGeom.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

p = squeeze( pressure, axis=(0,1) )
p = where( abs(p) < 1e-6, nan, p )
tl = -20*log10( abs( p ) )
indexes = isnan( tl )
tl[ indexes ] = 140.0

figure(1)
imshow(tl,extent=[0,rmaxkm,-Dmax,Dmax],aspect='auto',cmap='jet_r',origin='lower',vmin=60,vmax=120)
plot(ratikm,-zati,'b')
plot(rbtykm,zbty,'k')
cb = colorbar()
cb.ax.invert_yaxis()
plot(rs,zs,marker="<",markersize=16,color="k")
xlabel('Range (km)')
ylabel('Depth (m)')
title('Bellhop - Parabolic bottom profile, Geometric beams')
xlim(0,rmaxkm)
ylim(Dmax,-Dmax)

show()

print("done.")
