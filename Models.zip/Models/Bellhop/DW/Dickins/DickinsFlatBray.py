#=======================================================================
# 
# Bellhop: Dickins Seamount
# Faro, Qua 19 Abr 2023 19:54:24 WEST 
# Written by Tordar 
# 
#=======================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python/")
from plotray import *

print("Bellhop - Dickins Seamount:") 
print("Ray trace run")
print("Geometric hat beams in Cartesian coordinates") 

system("bellhop.exe DickinsFlatBray")

figure(1)
plotray('DickinsFlatBray.ray')
xlabel('Range (m)')
ylabel('Depth (m)')
title("Bellhop - Dickins Seamount")

show()

print("done.")

