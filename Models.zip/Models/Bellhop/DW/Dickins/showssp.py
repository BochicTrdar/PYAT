#==================================================================
#  
#  Bellhop: Dickins sound speed profile
#  Faro, Ter Jul  4 22:52:17 WEST 2017
#  Written by Tordar
#  
#==================================================================

from os import *
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *

sspdata = loadtxt("dickins.ssp")

z = sspdata[:,0]; Dmax = max( z )
c = sspdata[:,1]

figure(1)
plot(c,-z)
xlabel('Sound Speed (m/s)')
ylabel('Depth (m)')
title('Bellhop - Dickins SSP')
grid(True)
show()

print('done.')
