#==================================================================
#  
#  Bellhop: point source in free space
#  Faro, Qua 19 Abr 2023 20:09:09 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python")
from readshd import *

rs = 0.0

print("Bellhop - point source in free space")

system("bellhop.exe omni")

filename = 'omni.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

p = squeeze( pressure, axis=(0,1) )
p = where( abs(p) < 1e-6, nan, p )
tl = -20*log10( abs( p ) )
indexes = isnan( tl )
tl[ indexes ] = 100.0

figure(1)
imshow(tl,extent=[-rmaxkm,rmaxkm,-Dmax,Dmax],aspect='auto',cmap='jet_r',origin='lower',vmin=40,vmax=90)
cb = colorbar()
cb.ax.invert_yaxis()
plot(rs,zs,marker="<",markersize=16,color="k")
xlabel('Range (km)')
ylabel('Depth (m)')
title('Bellhop - point source in free space')
xlim(0,rmaxkm)
ylim(Dmax,0)

show()

print("done.")
