#==================================================================
#  
#  Bellhop - Lower halfspace
#  Faro, Qua 19 Abr 2023 20:44:39 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
import sys
sys.path.append ("../../../../Python/")
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
from mpl_toolkits.mplot3d import Axes3D
from read_arrivals_asc import *

print("Bellhop - Lower halfspace:")
print("Arrivals calculation, ASCII  file output")
print("Geometric hat beams in Cartesian coordinates") 

system("bellhop.exe lower_half_arr")

Arr, Pos = read_arrivals_asc( 'lower_half_arr.arr', 18 )

Narr   = int_( squeeze( Arr['Narr'] ) )
delay  = real( squeeze( Arr['delay'] ) )
A      = abs( squeeze( Arr['A'] ) )
rarray = squeeze( Pos['r_range'] )

Nrr = rarray.size

fig = figure()
ax = fig.gca(projection='3d')

for i in range(1,Nrr):
    tau = delay[i,0:Narr[i]]
    amp = abs( A[i,0:Narr[i]] )
    rangei = rarray[i]*ones(Narr[i])
    for j in range(Narr[i]):
        ax.plot([tau[j],tau[j]], [rangei[j],rangei[j]], [0.0,amp[j]],'b')    
        ax.plot([tau[j],tau[j]], [rangei[j],rangei[j]], [0.0,amp[j]],'bo')
xlabel('Travel time (s)')
ylabel('Range (in m)')
title('Bellhop - Lower halfspace')
show()

print("done.")
