#==================================================================
#  
#  Bellhop3D: Weymouth (Nx2D run)
#  Faro, Qua 19 Abr 2023 21:43:49 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append("../../../../Python")
from readshd import *

rs = 0.0

print("Bellhop3D - Weymouth (Nx2D run):")
print("Coherent TL calculation")
print("Geometric hat beams in Cartesian coordinates")

system("cp Weymouth.bty WeymouthNx2D.bty")
system("bellhop3d.exe WeymouthNx2D")
system("rm WeymouthNx2D.bty")

filename = 'WeymouthNx2D.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

p = squeeze( pressure )
tl = -20*log10( abs( p ) )
tl1 = squeeze( tl[0,:,:] )

figure(1)
imshow(tl1,extent=[0,rmaxkm,0,Dmax],aspect='auto',cmap='jet_r',origin='lower')
cb = colorbar()
cb.ax.invert_yaxis()
plot(rs,zs,marker="<",markersize=16,color="k")
xlabel('Range (km)')
ylabel('Depth (m)')
title('Bellhop3D - Weymouth (Nx2D run)')
ylim(Dmax,0)

show()

print("done.")
