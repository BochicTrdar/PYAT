#==================================================================
#  
#  Bellhop3D: Weymouth (Nx2D run)
#  Faro, Qua 19 Abr 2023 21:44:25 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append("../../../../Python")
from plotray3d import *

print("Bellhop3D - Weymouth (Nx2D run):")
print("Ray trace run")
print("Geometric hat beams in Cartesian coordinates")

system("cp Weymouth.bty WeymouthNx2D_ray.bty")
system("bellhop3d.exe WeymouthNx2D_ray")
system("rm WeymouthNx2D_ray.bty")

plotray3d('WeymouthNx2D_ray.ray')

show()

print("done.")
