#==================================================================
#  
#  Bellhop3D: Weymouth (3D run)
#  Faro, Qua 19 Abr 2023 21:43:27 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append("../../../../Python")
from plotray3d import *

print("Bellhop3D - Weymouth (3D run):")
print("Ray trace run")
print("Geometric hat beams in Cartesian coordinates")

system("cp Weymouth.bty Weymouth3D_ray.bty")
system("bellhop3d.exe Weymouth3D_ray")
system("rm Weymouth3D_ray.bty")

plotray3d('Weymouth3D_ray.ray')

show()

print("done.")
