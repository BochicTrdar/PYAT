#==================================================================
#  
#  Bellhop3D: Kermit-Roosevelt GeoGaussian beams, 1001 bearings x 701 declinations
#  Faro, Qua 19 Abr 2023 21:40:10 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append("../../../../Python")
from readshd import *

rs = 0.0

print("Bellhop3D - Kermit-Roosevelt GeoGaussian beams, 1001 bearings x 701 declinations:")
print("Coherent TL calculation")
print("Geometric gaussian beams")

system("bellhop3d.exe KR3dGaussian")

filename = 'KR3dGaussian.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

bearings = linspace(0,360,501)

[R,Bearings] = meshgrid(rarray,bearings)

X = R*cos( Bearings*pi/180 ); Xkm = X/1000
Y = R*sin( Bearings*pi/180 ); Ykm = Y/1000

p = squeeze( pressure )
tl = -20*log10( abs( p ) )

figure(1)
pcolor(Xkm,Ykm,tl,cmap='jet_r',vmin=40,vmax=80)
cb = colorbar()
cb.ax.invert_yaxis()
xlabel('X (km)')
ylabel('Y (km)')
title('Bellhop3D - Kermit-Roosevelt GeoGaussian beams, 1001 bearings x 701 declinations')

show()

print("done.")
