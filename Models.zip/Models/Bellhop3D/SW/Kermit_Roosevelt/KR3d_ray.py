#==================================================================
#  
#  Bellhop3D: Kermit-Roosevelt
#  Faro, Qua 19 Abr 2023 21:40:35 WEST 
#  Written by Tordar
#  
#==================================================================

# ipython: run KR3d_ray

from os import system
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append("../../../../Python")
from plotray3d import *

rs = 0.0

print("Bellhop3D - Kermit-Roosevelt:")
print("Ray trace run")
print("Cartesian beams")

system("bellhop3d.exe KR3d_ray")

plotray3d('KR3d_ray.ray')

show()

print("done.")
