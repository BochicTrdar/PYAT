#==================================================================
#  
#  KRAKEN: Pekeris waveguide
#  Faro, Qua 19 Abr 2023 22:04:17 WEST  
#  Written by Tordar 
#  
#==================================================================

from os import *
import sys
sys.path.append ("../../../../Python")
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
from wkrakenenvfil import *
from readshd import *
from readmod import *

print('Pekeris waveguide:') 

case_title = 'Pekeris waveguide'

freq =  170.0 # frequency in Hz
Dmax =  100.0 # depth in meters
cw   = 1500.0 # sound speed in water
cb   = 1700.0 # sound speed in lower halfspace
rhow =  1.0   # density in water
rhob =  2.0   # density in lower halfspace

zs = array([79.0]) # Source depth
rs = array([ 0.0]) # Source range (not used)

nza = 101; zarray = linspace(0,Dmax,nza)

rmin = 0; rmax = 1000.0; dr = 5.0
rarray   = arange(rmin,rmax+dr,dr); rarray[0] = 1; rmaxkm = rmax/1000
rarraykm = rarray/1000; nra = rarray.size

#==================================================================
#  
#  Source data
#  
#==================================================================

source_data = {"zs":zs, "f":freq}

#==================================================================
#  
#  Surface data
#  
#==================================================================

bc = 'V'
properties = [] # Not required (vacuum over surface)
reflection = [] # Not required for this case

surface_data = {"bc":bc,"properties":properties,"reflection":reflection}

#==================================================================
#  
#  Scatter data
#  
#==================================================================

# Scatter is not required for this case: 
bumden = [] # Bump density in ridges/km 
eta    = [] # Principal radius 1 of bump 
xi     = [] # Principal radius 2 of bump 

scatter_data= {"bumden":bumden,"eta":eta,"xi":xi}

#==================================================================
#  
#  Sound speed data
#  
#==================================================================

z = array([0,Dmax])
c = array([cw,cw])
cs = zeros(2)
rho = ones(2)
apt = cs
ast = cs
type  = 'H'
itype = 'N'
# Number of mesh points to use initially, should be about 10 per vertical wavelenght:
nmesh = 201
sigma = 0.0 # RMS roughness at the surface 
clow  = 0.0
chigh = 1.0e4

cdata = array([z,c,cs,rho,apt,ast])

ssp_data = {"cdata":cdata,"type":type,"itype":itype,"nmesh":nmesh,"sigma":sigma,"clow":clow,"chigh":chigh,"zbottom":Dmax}

#==================================================================
#  
#  Bottom data
#  
#==================================================================

layerp     = array([0, 0, Dmax])
layert     = 'R'
properties = array([Dmax, cb, 0, rhob, 0, 0])
bdata      = [];
units      = 'W';
bc	   = 'A';
sigma      = 0.0 # Interfacial roughness

bottom_data = {"n":1,"layerp":layerp,"layert":layert,"properties":properties,"bdata":bdata,"units":units,"bc":bc,"sigma":sigma}

#==================================================================
#  
#  Field data
#  
#==================================================================

rp    =   0 
np    =   1
m     = 999
rmodes = 'A'
stype  = 'R'
thorpe = 'T'
finder = ' '
dr     = zeros( nza )

field_data = {"rmax":rmaxkm,"nrr":nra,"rr":rarraykm,"rp":rp,"np":np,"m":m,"rmodes":rmodes,"stype":stype,"thorpe":thorpe,"finder":finder,"rd":zarray,"dr":dr,"nrd":nza}

print("Writing environmental file...")

wkrakenenvfil('pekeris',case_title,source_data,surface_data,scatter_data,ssp_data, bottom_data,field_data);

print( "Running KRAKEN..." )

system("kraken.exe pekeris")
system("cp field.flp pekeris.flp")
system("field.exe pekeris < pekeris.flp")

print( "Reading output data..." )

filename = 'pekeris.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

p = squeeze( pressure, axis=(0,1) )
tl = 20*log10( abs( p ) )

Modes,bc = readmod('pekeris.mod')

phi = Modes["phi"]
z   = Modes["z"]; nza = z.size
k   = Modes["k"]
nk  = k.size

amessage = 'Found ' + str(nk) + ' modes'
print( amessage )

figure(1)
imshow(tl,extent=[0,rmax,Dmax,0],cmap='jet',aspect='auto',vmin=-80,vmax=-30)
colorbar()
plot(rs[0],zs[0],marker="<",markersize=16,color="k")
xlabel('Range (m)')
ylabel('Depth (m)')
#ylim(Dmax,0)

figure(2)
#pcolormesh(arange(nk)+1,z,real(phi),shading='auto',cmap='jet',vmin=-0.1,vmax=0.1)
#imshow(real(phi),extent=[1,nk,max(z),0], aspect='auto',cmap='jet',vmin=-0.1,vmax=0.1)
#colorbar()
#xlim(1,nk-1)
#ylim(max(z),0)
for i in range(4):  
   rphi = real( phi[ : , i ] ) 
   iphi = imag( phi[ : , i ] )
   thetitle = r'$Z_'  + str(i+1) + '(z)$' 
   subplot(1,4,i+1)
   plot(rphi,-z,iphi,-z,'r--')
   title( thetitle )
   grid(True)
subplot(141)
ylabel('Depth (m)')

show()

print("done.")
