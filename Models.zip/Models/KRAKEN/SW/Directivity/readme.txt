=======================================================================
Faro, Seg 15 Mar 2021 10:55:13 WET 

Orlando,

Thanks - you can reduce the sidelobes with a taper (Hann or Hamming for instance) if you want,

Mike

Michael Porter, Ph.D.
President and CEO

Heat, Light, and Sound Research, Inc.
http://www.hlsresearch.com/
=======================================================================
