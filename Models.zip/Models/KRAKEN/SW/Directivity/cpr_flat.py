#==================================================================
#  
#  KRAKEN: Pekeris waveguide with source directivity
#  Faro, Qua 19 Abr 2023 22:03:09 WEST 
#  Written by Tordar 
#  
#==================================================================

from os import *
import sys
sys.path.append ("../../../../Python")
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
from readshd import *

print('Pekeris waveguide with source directivity:') 

print( "Running KRAKEN..." )
system("kraken.exe pekeris")
system("cp field.flp pekeris.flp")
system("field.exe pekeris < pekeris.flp")
print( "Reading output data..." )
filename = 'pekeris.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

p = squeeze( pressure, axis=(0,1) )
tl = 20*log10( abs( p ) )

#rarray = geometry['rarray']
#zarray = geometry['zarray']

figure(1)
imshow(tl, aspect='auto',vmin=-90,vmax=0)
#imshow(tl,extent=[rarray[0],rarray[-1],-zarray[-1],zarray[0]], aspect='auto',vmin=-90,vmax=0)
#colorbar()
#plot(rs[0],-zs[0],marker="<",markersize=16,color="k")
#xlabel('Range (m)')
#ylabel('Depth (m)')
show()

print("done.")
