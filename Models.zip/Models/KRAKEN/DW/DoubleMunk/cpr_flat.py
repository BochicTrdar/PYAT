#==================================================================
#  
#  KRAKEN: Souble Munk profile
#  Faro, Qua 19 Abr 2023 21:51:04 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python")
from readmod import *
from readshd import *
from wkrakenenvfil import *

case_title = 'Double Munk SSP' 

freq = 50.0; w = 2*pi*freq

sspdata = loadtxt("doublemunk.ssp")

z0 = sspdata[:,0]; zmax = max( z0 )
c0 = sspdata[:,1]; cmin = min( c0 ); kmax = w/cmin

rmax = 5000.0; rmaxkm = rmax/1000
nra = 201; rarray = linspace(0,rmax,nra); rarray[0] = 1.0; rarraykm = rarray/1000
nza = 201; zarray = linspace(0,zmax,nza)
#==================================================================
#  
#  Source data
#  
#==================================================================

rs = array([  0.0])
zs = array([500.0])
source_data = {"zs":zs, "f":freq}

#==================================================================
#  
#  Surface data
#  
#==================================================================

bc = 'V'
properties = [] # Not required (vacuum over surface)
reflection = [] # Not required for this case

surface_data = {"bc":bc,"properties":properties,"reflection":reflection}

#==================================================================
#  
#  Scatter data
#  
#==================================================================

# Scatter is not required for this case: 
bumden = [] # Bump density in ridges/km 
eta    = [] # Principal radius 1 of bump 
xi     = [] # Principal radius 2 of bump 

scatter_data= {"bumden":bumden,"eta":eta,"xi":xi}

#==================================================================
#  
#  Sound speed data
#  
#==================================================================

nz = z0.size
cs = zeros(nz)
rho = ones(nz)
apt = cs
ast = cs
type  = 'H'
itype = 'N'
# Number of mesh points to use initially, should be about 10 per vertical wavelenght:
nmesh = 0
sigma = 0.0 # RMS roughness at the surface 
clow  = 1500.0
chigh = 1800.0

cdata = array([z0,c0,cs,rho,apt,ast])

ssp_data = {"cdata":cdata,"type":type,"itype":itype,"nmesh":nmesh,"sigma":sigma,"clow":clow,"chigh":chigh,"zbottom":zmax}

#==================================================================
#  
#  Bottom data
#  
#==================================================================

layerp     = array([0, 0, zmax])
layert     = 'R'
properties = array([zmax,1750.0,0.0,0.8,0.0,1.9])
bdata      = [];
units      = 'W';
bc	   = 'A';
sigma      = 0.0 # Interfacial roughness
bottom_data = {"n":1,"layerp":layerp,"layert":layert,"properties":properties,"bdata":bdata,"units":units,"bc":bc,"sigma":sigma}

#==================================================================
#  
#  Field data
#  
#==================================================================

rp    =   0 
np    =   1
m     = 999
rmodes = 'A'
stype  = 'R'
thorpe = 'T'
finder = ' '
dr     = zeros( nza )

field_data = {"rmax":rmaxkm,"nrr":nra,"rr":rarraykm,"rp":rp,"np":np,"m":m,"rmodes":rmodes,"stype":stype,"thorpe":thorpe,"finder":finder,"rd":zarray,"dr":dr,"nrd":nza}

print("Writing environmental file...")

wkrakenenvfil('doublemunk',case_title,source_data,surface_data,scatter_data,ssp_data, bottom_data,field_data)

print( "Running KRAKEN..." )

system("krakenc.exe doublemunk")
system("cp field.flp doublemunk.flp")
system("field.exe doublemunk < doublemunk.flp")

print( "Reading output data..." )

filename = 'doublemunk.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

Modes,bc = readmod('doublemunk.mod')

p = squeeze( pressure, axis=(0,1) )
tl = 20*log10( abs( p ) )

figure(1)
imshow(tl,extent=[0,rmax,zmax,0], aspect='auto',cmap='jet',vmin=-80,vmax=-30)
colorbar()
plot(rs[0],zs[0],marker="<",markersize=16,color="k")
xlabel('Range (m)')
ylabel('Depth (m)')
ylim(zmax,0)

phi = Modes["phi"]
z   = Modes["z"]; nza = z.size
k   = Modes["k"]
nk  = k.size

amessage = 'Found ' + str(nk) + ' modes'
print( amessage )

km = real( k ) # If complex then imaginary part means leaky modes...
kv = sqrt( kmax*kmax - km*km )
thetam = arctan2(kv,km)*180/pi

# Skip distances: 
Dm = -2*pi/diff( km )
Dmkm = Dm/1000

# Field for specific modes:
#pmodes = zeros((nza,nra)) + 1j*zeros((nza,nra))

#e0 = sqrt( 2*pi )

#for i in range(nk):
#    Z = phi[:,i]
#    interpolator = interp1d(z, Z)
#    Zs = interpolator( zs )      
#    Z  = Zs*Z
#    R  = exp( -1j*k[i]*rarray )/sqrt( k[i]*rarray )
#    [RM,ZM] = meshgrid(R,Z)
#    pmodes  = pmodes + RM*ZM

#pmodes = pmodes*e0

#tlmodes = 20*log10( abs( pmodes ) )

#figure(2)
#imshow(tlmodes,extent=[0,rmax,-max(z),0], aspect='auto',cmap='jet',vmin=-80,vmax=-30)
#colorbar()
#plot(rs[0],-zs[0],marker="<",markersize=16,color="k")
#xlabel('Range (m)')
#ylabel('Depth (m)')
#ylim(-max(z),0)

figure(3)
#pcolormesh(arange(nk)+1,z,real(phi),shading='auto',cmap='jet',vmin=-0.1,vmax=0.1)
imshow(real(phi),extent=[1,nk,max(z),0], aspect='auto',cmap='jet',vmin=-0.1,vmax=0.1)
colorbar()
xlim(1,nk-1)
ylim(max(z),0)
#for i in range(4):  
#   rphi = real( phi[ : , i ] ) 
#   iphi = imag( phi[ : , i ] )
#   thetitle = r'$Z_'  + str(i+1) + '(z)$' 
#   subplot(1,4,i+1)
#   plot(rphi,-z,iphi,-z,'r--')
#   title( thetitle )
#   grid(True)
#subplot(141)
#ylabel('Depth (m)')

#figure(4)
#stem(arange(nk)+1,thetam)
#xlabel(r'Mode index $m$')
#ylabel(r'Modal angle $\theta_m$')
#grid(True)

#figure(5)
#stem(arange(nk-1)+1,Dm)
#xlabel(r'Mode index $m$')
#ylabel(r'Skip distance $D_m$')
#grid(True)

figure()
stem(thetam[0:-1],Dmkm)
xlabel(r'Modal angle $\theta_m$ (degrees)')
ylabel(r'Skip distance $D_m$ (km)')
grid(True)

show()

print("done.")
