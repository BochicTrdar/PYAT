#==================================================================
#  
#  KRAKEN: Leaky surface duct
#  Faro, Qua 19 Abr 2023 21:56:34 WEST 
#  Written by Tordar
#  
#==================================================================

from numpy import *
from scipy.io import *
from matplotlib.pyplot import *

sspdata = loadtxt("sductK.ssp")

z = sspdata[:,0]; zmin = min( z); zmax = max( z )
c = sspdata[:,1]

figure(1)
plot(c,z)
xlabel('Sound Speed (m/s)')
ylabel('Depth (m)')
title('KRAKEN - Leaky surface duct')
ylim(zmax,zmin)
grid(True)
show()

print('done.')
