#==================================================================
#  
#  KRAKEN: Munk profile
#  Faro, Qua 19 Abr 2023 21:54:46 WEST 
#  Written by Tordar
#  
#==================================================================

from os import system
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *
sys.path.append ("../../../../Python")
from readmod import *
from readshd import *

rs = 0.0

freq = 50.0; w = 2*pi*freq

sspdata = loadtxt("MunkK.ssp")

z = sspdata[:,0]; Dmax = max( z )
c = sspdata[:,1]; cmin = min( c ); kmax = w/cmin

print("KRAKEN - Munk profile")

system("kraken.exe MunkK")
system("field.exe MunkK < MunkK.flp")

filename = 'MunkK.shd'
xs = nan
ys = nan
pressure,geometry = readshd(filename,xs,ys)

zs     = geometry["zs"]
rarray = geometry["rarray"]; rarraykm = rarray/1000
zarray = geometry["zarray"]

Dmax = zarray[-1]
rmax = rarray[-1]; rmaxkm = rmax/1000

Modes,bc = readmod('MunkK.mod')

phi = Modes["phi"]
z   = Modes["z"]; nza = z.size
k   = Modes["k"]
nk  = k.size

amessage = 'Found ' + str(nk) + ' modes'
print( amessage )

km = real( k ) # If complex then imaginary part means leaky modes...
kv = sqrt( kmax*kmax - km*km )
thetam = arctan2(kv,km)*180/pi

# Skip distances: 
Dm = -2*pi/diff( km )

p = squeeze( pressure, axis=(0,1) )
tl = -20*log10( abs( p ) )

figure()
imshow(tl,extent=[0,rmaxkm,0,Dmax],aspect='auto',cmap='jet_r',origin='lower',vmin=40,vmax=90)
cb = colorbar()
cb.ax.invert_yaxis()
plot(rs,-zs,marker="<",markersize=16,color="k")
xlabel('Range (km)')
ylabel('Depth (m)')
title('KRAKEN - Munk profile')
ylim(Dmax,0)

figure()
#pcolormesh(arange(nk)+1,z,real(phi),shading='auto',cmap='jet',vmin=-0.1,vmax=0.1)
imshow(real(phi),extent=[1,nk,max(z),0], aspect='auto',cmap='jet',vmin=-0.1,vmax=0.1)
colorbar()
xlim(1,nk-1)
ylim(max(z),0)
#for i in range(4):  
#   rphi = real( phi[ : , i ] ) 
#   iphi = imag( phi[ : , i ] )
#   thetitle = r'$Z_'  + str(i+1) + '(z)$' 
#   subplot(1,4,i+1)
#   plot(rphi,-z,iphi,-z,'r--')
#   title( thetitle )
#   grid(True)
#subplot(141)
#ylabel('Depth (m)')

figure()
stem(arange(nk)+1,thetam)
xlabel(r'Mode index $m$')
ylabel(r'Modal angle $\theta_m$')
grid(True)

figure()
stem(arange(nk-1)+1,Dm)
xlabel(r'Mode index $m$')
ylabel(r'Skip distance $D_m$')
grid(True)

show()

print("done.")
