#==================================================================
#  
#  KRAKEN: Munk sound speed profile
#  Boston, qua jun 28 12:16:50 WEST 2017
#  Written by Tordar
#  
#==================================================================

from os import *
import sys
from numpy import *
from scipy.io import *
from matplotlib.pyplot import *

sspdata = loadtxt("munk.ssp")

z = sspdata[:,0]; Dmax = max( z )
c = sspdata[:,1]

figure(1)
plot(c,-z)
xlabel('Sound Speed (m/s)')
ylabel('Depth (m)')
title('KRAKEN - Munk SSP')
grid(True)
show()

print('done.')
